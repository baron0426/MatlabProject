clear all; %main program for question 6
close all;
clc;
[music,fs] = audioread("../fmt.wav");
sound(music,fs);
